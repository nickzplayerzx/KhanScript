# 🔹 KhanTool
### O cheat mais avançado para a Khan Academy.

🙂 Bookmarklet:
```js
javascript:fetch("https://raw.githubusercontent.com/OnePrism0/KhanTool/refs/heads/main/KhanTool.js").then(t=>t.text()).then(eval);
```

Copyright (C) 2025 KhanNickz

Créditos pelo script ao Kovez/zStuartbw e Nickz
